# CashAhead judge demo files

Open CashAhead on the demo computer and select **Try the judge demo**. If you are evaluating a hosted copy, use the same button on its home page. The opening scene is Monday 23 November 2026 in Ananya Rao Photography’s sample studio. Friday’s crew and lens rental cost ₹10,000. The studio has ₹6,000 and the ₹11,000 wedding balance has slipped by 15 days.

## Let the judge make an offer

1. Start a fresh judge demo. Choose **Test a client offer** on Rescue plan. Reddy–Varma asks to pay the ₹11,000 wedding balance on Saturday. Read the last safe full-payment date and Friday’s two bills.
2. Let the judge enter an amount on Friday and choose the balance date. With ₹3,000 Friday and the rest Saturday, Friday still needs ₹1,000. CashAhead drafts a counteroffer of ₹4,000 Friday and ₹7,000 Saturday. Try **Use smallest split** and **Copy reply**.
3. Open **What if this client can’t pay?** to see the fallback. **Save agreed promise** records the selected covered terms. Cash stays at ₹6,000 until a receipt arrives. Use **Studio settings → Restart judge demo** before following the original bank-import walkthrough below.

## The two-minute route

1. On **Rescue plan**, leave Kiran & Divya at **50%**. ₹4,000 of their ₹8,000 invoice covers Friday. Select **25%**. Their ₹2,000 would leave ₹2,000 to find, so the suggested first call switches to Lakshmi & Arjun for an early deposit. Switch back to **50%**. Under **Compare actions**, open Kiran & Divya’s **Draft reminder** and choose **Mark followed up**.
2. Extract this ZIP. Open **Bank import → Statement CSV** and select **CashAhead-sample-statement.csv**. Find **DEMO-KD-5000**, check that **Allocate transfer** shows **INV-101**, then click **Confirm selection** on that row only. The other credit has no identified payer. Leave it for review. The debit is skipped.
3. Open **Overview**. Cash is **₹11,000** and Friday closes at **+₹1,000**. Open **Invoices → Overdue → Kiran & Divya** to see **₹3,000** still due and the bank-confirmed receipt. Upload the same CSV again to see **1 already processed**.
4. Open **Booking deposit → Try worked example**. The example has ₹6,000 available, a ₹3,000 safety buffer and a ₹10,000 shoot cost. The minimum deposit is **₹7,000** on a ₹30,000 booking. Set **Cost amount** to **12000**. The deposit becomes **₹9,000** and the final balance **₹21,000**.

## Try one alternative at a time

Choose **Studio settings → Restart judge demo** before each alternative. Upload one extracted CSV through **Bank import → Statement CSV**. The same files are available there from **Download sample CSV** and **Download more demo statements**. All records are fictional.

| File | What to do | Expected result |
|---|---|---|
| CashAhead-small-payment.csv | Confirm **JUDGE-KD-2000 → INV-101**. | Cash ₹8,000. Friday −₹2,000. Kiran & Divya still owe ₹6,000. |
| CashAhead-review.csv | The row **JUDGE-CONFLICT** names Mehta but references Kiran & Divya’s invoice. Leave it pending until the payer can be verified. For **JUDGE-IGNORE**, choose **Ignore this credit → Confirm selection**. | The conflict has no preselected invoice. One debit is skipped, a bad date is flagged, and ignoring a row leaves cash at ₹6,000. |
| CashAhead-overpayment.csv | Confirm **JUDGE-KD-10000 → INV-101**. | ₹10,000 enters cash, ₹8,000 clears the invoice, and ₹2,000 appears under **Unapplied credits**. Cash ₹16,000. Friday +₹6,000. |
| CashAhead-sample-statement.csv | To test a manual entry, first open **Invoices → Kiran & Divya → Record payment**. Enter **5000**, leave the sample date and enter bank reference **DEMO-KD-5000**. Confirm. Upload the file, choose **Link existing receipt** on its ₹5,000 row, and confirm. | The transfer links to the original receipt. Cash stays at ₹11,000 and the invoice balance stays at ₹3,000. |

## Try the forms without a file

- **Invoice and follow-up.** Restart the judge demo. Open **Invoices → + New invoice**. Enter client **Nila Rao**, service **Portrait shoot**, amount **6000**, contractual due date **2026-11-18** and type **Final balance**. Save. Open Nila’s invoice, draft a reminder, then record **1500** received on **2026-11-23**. The balance is **₹4,500**, five days overdue. Overview shows **₹7,500** cash and Friday **−₹2,500**.
- **Forecast.** For the original on-time baseline, open **Try the sample studio** from the home page on a fresh sample, or use **Studio settings → Reset sample studio → Restore sample** within that sample. In **Forecast**, select **30d**, **60d** or **90d**. Click Friday for the crew and rental breakdown. Choose **What if a client pays late? → INV-104**, enter **15** days and compare **+₹7,000 → −₹4,000**. **Cancel preview** leaves the old forecast in place. **Confirm expected date** applies the delay.
- **Vendor agreement.** From a fresh judge demo, open **Rescue plan → Compare actions → Move LensHub · lens rental → Review date**. Confirm only if acting out vendor approval. In **Bills**, the ₹4,000 rental moves from **27 November** to **4 December**. Friday then closes at **₹0**. Restart before the next run.

Use the **judge demo** for practice. Its restart clears the tab’s demo entries. The **My studio** workspace is for your own records.
